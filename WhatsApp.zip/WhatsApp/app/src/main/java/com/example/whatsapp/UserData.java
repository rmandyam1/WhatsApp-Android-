package com.example.whatsapp;

public class UserData {
    String username;
    String imageLink;

    public UserData(String username, String imageLink) {
        this.username = username;
        this.imageLink = imageLink;
    }
}
